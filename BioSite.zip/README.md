# bioSite
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CSD 340 Web Development with HTML and CSS</title>
</head>
<body>
    <h1>CSD 340 Web Development with HTML and CSS</h1>
    <h2>Contributors</h2>
    <ul>
        <li> Adam Bailey</li>
        <li> Ean Masoner</li>
    </ul>
</body>
</html>
